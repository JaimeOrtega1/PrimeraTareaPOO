# -django-devs-template
Plantilla inicial para proyectos en Django
